define(["require"], function(require){
	return {
	account:require.toUrl("movement/data/movement.json")}
});
