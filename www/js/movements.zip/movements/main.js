define(["movement/view/movement"],function(movement){
	var movementView = new movement({el:'#movements',topic:"showmovements"});
	
});
