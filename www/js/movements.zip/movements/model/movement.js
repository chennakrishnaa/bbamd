define(["backbone"], function(Backbone) {
	//config holds the url for data fetch
	return Backbone.Model.extend({
		
	});

});
